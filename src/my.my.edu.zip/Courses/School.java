package Courses;
public enum School {
    CSMath, CE, EE, Chem, Phy, Langs
}
