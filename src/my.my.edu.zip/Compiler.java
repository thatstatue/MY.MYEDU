import java.io.File;

public interface Compiler {
    public void exportData(File file);
    public void importData(File file);
}
